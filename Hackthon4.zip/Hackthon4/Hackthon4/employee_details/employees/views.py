from django.shortcuts import render
import random

def employee_form(request):
    return render(request, 'employees/emp_form.html')


def result(request):
    if request.method == 'POST':
        name = request.POST.get('ename', 'Unknown')
        age = request.POST.get('age', 'Unknown')

        gross_salary = request.POST.get('gross_salary', '0')
        tax_rate = request.POST.get('tax', 0)
        bonus_rate = request.POST.get('bonus', 0)

        tax_amount = float(gross_salary) * float(tax_rate) / 100
        bonus_amount = float(gross_salary) * float(bonus_rate) / 100
        net_salary = float(gross_salary) + bonus_amount - tax_amount

        context = {
            'name': name,
            'age': age,
            'gross_salary': gross_salary,
            'tax': float(tax_rate) / 100,
            'bonus': float(bonus_rate) / 100,
            'netsalary': net_salary
        }

        return render(request, 'employees/emp_details.html', context)

    return render(request, 'employees/emp_form.html')


def jumbled_word(request):
    context = {}

    if request.method == 'POST':
        word = request.POST.get('word', '')
        letters = list(word)
        random.shuffle(letters)
        jumbled = ''.join(letters)

        context = {
            'word': jumbled
        }

    return render(request, 'employees/jumble_words.html', context)
