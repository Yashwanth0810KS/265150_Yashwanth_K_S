from django.urls import path
from . import views

urlpatterns = [
    path('get_form',views.employee_form,name='get_form'),
    path('get_result',views.result,name='get_result'),
    path('get_jumble',views.jumbled_word,name='get_jumble'),

]